##W-Semiar: Informatik 2013/14
####Verwirklichung einer Modseite für [Minecraft](https://minecraft.net/)
___
Ziel des W-Seminars ist die Erstellung einer Seite, welche die Sprachen HTML, php und SQL verbindet um eine dynamische Website zu ermöglichen. Das gewählte Thema dieser Website ist eine online-Modsammlung anzulegen, welche durch viele Benutzer betrieben wird.
Die Motivation hierbei ist eine verbesserte Konkurrenzplatform zu der bereits bestehenden [Technicplatform](http://technicpack.net) und der in Entwicklung befindlichen Feed the Best/Curse Platform zu entwickeln, welche sich ebenfalls nicht im Besitz eines Unternehmens befindet. Sondern völlig frei den bestmöglichen Service im Sinn hat.

###Features

* Markdown Editor für Seiten
* Blogs für Mod-Entwickler
* Updates für registrierte Benutzer
* Leichtes finden von Mods

###Ausblick
Natürlich bleibt auch nach Abschluss des Seminars noch viel Arbeit übrig, insbesondere falls die Platform von der Community akzeptiert wird. Weiterhin kann der Code optimiert und umgestaltet werden, sowie neue Features welche hinzugefügt werden um die Benutzung weiter zu verbessern.