<?php
function ttruncat($text,$numb) {
	    if (strlen($text) > $numb) {
	        $text = substr($text, 0, $numb);
	        $text = substr($text,0,strrpos($text," "));
	        $etc = " ..."; 
	        $text = $text.$etc;
	    }
	    return $text;
}

class SearchController extends BaseController 
{
    
    public function getFetch ($id)
    {
        $mods=Mod::lists('name');
        
        foreach ($mods as $i=>$mod)
        {
            $res[$i]=$mod;
        }
        
        return Response::json($res);
    
    }
    
    
    public function postMods ($mist)
    {
        $mods=Mod::all();
        foreach ($mods as $i=>$mod)
        {
            $res[$i]['title']=$mod->name;
            $res[$i]['url']=URL::to("mod/view/$mod->id");
            $res[$i]['text']=ttruncat($mod->description,100);
        }
        $result["results"]=$res;
        return Response::json($result);
    }
    
    
    public function postIndex ()
    {
        $query = Input::get("search");
        $mod = false;
        
        $mod=Mod::where("name",$query)->first()["id"];
        
        if ($mod)
            return Redirect::to("mod/view/$mod");
        
        Alert::add("warning","No mod with this name existing.");
        return Redirect::to("mod/browse");
        
        
    }
    
    
}