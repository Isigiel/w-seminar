<?php

class ConfigController extends BaseController 
{
    
}